module.exports=[53009,(a,b,c)=>{}];

//# sourceMappingURL=web__next-internal_server_app_%28private%29_products_page_actions_1wpoxdsaf0n1g.js.map