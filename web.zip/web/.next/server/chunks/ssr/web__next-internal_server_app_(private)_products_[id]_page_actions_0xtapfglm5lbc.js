module.exports=[97329,(a,b,c)=>{}];

//# sourceMappingURL=web__next-internal_server_app_%28private%29_products_%5Bid%5D_page_actions_0xtapfglm5lbc.js.map