module.exports=[68819,(a,b,c)=>{}];

//# sourceMappingURL=0vkm_server_app_%28private%29_products_%5Bid%5D_edit_page_actions_0f2o1nqew85ef.js.map