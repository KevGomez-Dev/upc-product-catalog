module.exports=[65331,a=>{"use strict";var b=a.i(87924),c=a.i(18700);a.s(["default",0,function({reset:a}){return(0,b.jsxs)("main",{className:"recovery",children:[(0,b.jsx)("h1",{children:"Catálogo UPC"}),(0,b.jsx)(c.D,{message:"No se pudo abrir la página. Revisa la conexión e intenta de nuevo.",retry:a})]})}])}];

//# sourceMappingURL=web_src_app_error_tsx_1ut6kb_cp13d5._.js.map