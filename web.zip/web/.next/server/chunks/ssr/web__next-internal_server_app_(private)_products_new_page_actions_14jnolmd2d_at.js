module.exports=[16421,(a,b,c)=>{}];

//# sourceMappingURL=web__next-internal_server_app_%28private%29_products_new_page_actions_14jnolmd2d_at.js.map