module.exports=[72396,(e,o,d)=>{}];

//# sourceMappingURL=0b9d__next-internal_server_app_api_catalog_%5B___segments%5D_route_actions_1mor7lkmy3l-9.js.map