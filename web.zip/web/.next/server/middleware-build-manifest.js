globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/wp8ompGoeioJeBqGHjCkh/_buildManifest.js",
    "static/wp8ompGoeioJeBqGHjCkh/_ssgManifest.js",
    "static/wp8ompGoeioJeBqGHjCkh/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/1wnov70f88xjy.js",
    "static/chunks/39_j1bdzreq0m.js",
    "static/chunks/0c1ad7rcpjghx.js",
    "static/chunks/turbopack-2u1d16houkiyo.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/1wnov70f88xjy.js",
        "static/chunks/39_j1bdzreq0m.js",
        "static/chunks/0c1ad7rcpjghx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/1wnov70f88xjy.js",
        "static/chunks/39_j1bdzreq0m.js",
        "static/chunks/0c1ad7rcpjghx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/1wnov70f88xjy.js",
        "static/chunks/39_j1bdzreq0m.js",
        "static/chunks/0c1ad7rcpjghx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(private)/products/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/1wnov70f88xjy.js",
        "static/chunks/39_j1bdzreq0m.js",
        "static/chunks/0c1ad7rcpjghx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(private)/products/[id]/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/1wnov70f88xjy.js",
        "static/chunks/39_j1bdzreq0m.js",
        "static/chunks/0c1ad7rcpjghx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(private)/products/[id]/edit/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/1wnov70f88xjy.js",
        "static/chunks/39_j1bdzreq0m.js",
        "static/chunks/0c1ad7rcpjghx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(private)/products/new/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/1wnov70f88xjy.js",
        "static/chunks/39_j1bdzreq0m.js",
        "static/chunks/0c1ad7rcpjghx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/login/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/1wnov70f88xjy.js",
        "static/chunks/39_j1bdzreq0m.js",
        "static/chunks/0c1ad7rcpjghx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
