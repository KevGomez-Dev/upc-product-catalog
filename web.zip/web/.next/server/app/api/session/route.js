var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/session/route.js")
R.c("server/chunks/[externals]__1-5jwwvtu32ml._.js")
R.c("server/chunks/[root-of-the-server]__0xwjsun8zp7ip._.js")
R.c("server/chunks/_0gwxapf1oo7dd._.js")
R.c("server/chunks/web__next-internal_server_app_api_session_route_actions_0mv-qg8s3d0zl.js")
R.m(74405)
module.exports=R.m(74405).exports
