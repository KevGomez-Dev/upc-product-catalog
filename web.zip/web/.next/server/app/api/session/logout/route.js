var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/session/logout/route.js")
R.c("server/chunks/[externals]__1-5jwwvtu32ml._.js")
R.c("server/chunks/[root-of-the-server]__0xwjsun8zp7ip._.js")
R.c("server/chunks/_0nmrj3qajfyhl._.js")
R.c("server/chunks/web__next-internal_server_app_api_session_logout_route_actions_1_165oozxyjte.js")
R.m(55144)
module.exports=R.m(55144).exports
