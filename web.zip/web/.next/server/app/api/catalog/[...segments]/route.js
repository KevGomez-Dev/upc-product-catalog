var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/catalog/[...segments]/route.js")
R.c("server/chunks/[externals]__1-5jwwvtu32ml._.js")
R.c("server/chunks/[root-of-the-server]__0xwjsun8zp7ip._.js")
R.c("server/chunks/_0h521yvww1rph._.js")
R.c("server/chunks/0b9d__next-internal_server_app_api_catalog_[___segments]_route_actions_1mor7lkmy3l-9.js")
R.m(72431)
module.exports=R.m(72431).exports
